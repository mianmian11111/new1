import pandas as pd
import ast

# 读取CSV文件
df = pd.read_csv('/share/home/u2315363122/MI4D/mi4d-j/mi4d-j/gradmask/dataset/sst2/sentence_layer_sim/bert_if_fine_tuning/textfooler/att_test.csv')

print(f'原始数据行数: {len(df)}')

# 定义一个函数来提取列表最后一个元素
def get_last_element(layer_sim_str):
    layer_sim_list = ast.literal_eval(layer_sim_str)  # 将字符串转换为列表
    return float(layer_sim_list[-1])

# 过滤掉最后一个数字大于0.4的行
filtered_df = df[df['layers_sim'].apply(get_last_element) >= 0.35]

# 计算被删除的行数
removed_rows_count = len(df) - len(filtered_df)

# 输出结果
filtered_df.to_csv('/share/home/u2315363122/MI4D/mi4d-j/mi4d-j/gradmask/dataset/sst2/sentence_layer_sim/bert_if_fine_tuning/textfooler/处理后的/att_test_c.csv', index=False)  # 保存过滤后的数据
print(f'被删除的行数: {removed_rows_count}')