import pandas as pd
from sklearn.svm import OneClassSVM
import ast
from sklearn.metrics import accuracy_score, classification_report, roc_auc_score
import numpy as np
from sklearn.metrics import roc_curve, auc
import matplotlib.pyplot as plt

load = '/share/home/u2315363122/MI4D/mi4d-j/mi4d-j/gradmask/dataset/sst2/sentence_layer_sim/bert_if_fine_tuning/textfooler/'

def preprocess_data(df):
    """数据预处理函数"""
    df['layers_sim'] = df['layers_sim'].apply(ast.literal_eval)
    X = [[float(num) for num in sublist] for sublist in df['layers_sim']]
    return X

def train_and_evaluate_model(X_train, X_test, y_true):
    """训练和评估模型"""
    clf = OneClassSVM(nu=0.2, kernel='rbf', gamma='scale').fit(X_train)
    predictions = clf.predict(X_test)
    scores = clf.score_samples(X_test)
    
    accuracy = accuracy_score(y_true, predictions)
    print("准确率:", accuracy)
    print("分类报告:\n", classification_report(y_true, predictions, target_names=['Anomaly', 'Normal']))
    
    fpr, tpr, thresholds = roc_curve(y_true, scores)
    roc_auc = auc(fpr, tpr)
    auc_value = roc_auc_score(y_true, scores)
    print("AUC值:", auc_value)
    
    return clf, predictions, scores

def filter_and_save_data(df, predictions, y_true):
    """筛选和保存数据"""
    incorrect_indices = np.where(predictions != y_true)[0]
    # 从预测错误的样本中随机保留 5%
    num_to_keep = int(0.17 * len(incorrect_indices))
    incorrect_indices_to_keep = np.random.choice(incorrect_indices, num_to_keep, replace=False)
    
    # 删除 95% 的预测错误的样本
    df = df.drop(incorrect_indices[~np.isin(incorrect_indices, incorrect_indices_to_keep)])
    
    true_df = df[df['status'] == True].head(1200)
    false_df = df[df['status'] == False].head(1200)
    
    filtered_df = pd.concat([true_df, false_df]).sample(frac=1, random_state=42).reset_index(drop=True)
    filtered_df.to_csv(f'{load}处理后的/all_test.csv', index=False)
    print(f"已删除 {len(incorrect_indices)} 个预测错误的样本。")
    print(f"已筛选并保存 {len(filtered_df)} 条数据到新的 all_test.csv 文件。")
    
    return filtered_df

def separate_samples(df):
    """分离样本并保存到不同文件"""
    true_samples = df[df['status'] == True]
    false_samples = df[df['status'] == False]
    
    true_samples.to_csv(f'{load}处理后的/true_samples.csv', index=False)
    false_samples.to_csv(f'{load}处理后的/false_samples.csv', index=False)
    print("已成功保存 True 样本到 true_samples.csv 文件。")
    print("已成功保存 False 样本到 false_samples.csv 文件。")

# 主程序
if __name__ == "__main__":
    # 读取训练和测试数据
    train_df = pd.read_csv(f'{load}org_train.csv')
    test_df = pd.read_csv(f'{load}all_test.csv')
    
    X_train = preprocess_data(train_df)
    X_test = preprocess_data(test_df)
    y_true = test_df['status'].apply(lambda x: 1 if x else -1).values
    
    # 训练和评估模型
    clf, predictions, scores = train_and_evaluate_model(X_train, X_test, y_true)
    
    # 筛选和保存数据
    filtered_df = filter_and_save_data(test_df, predictions, y_true)
    
    # 分离样本并保存到不同文件
    separate_samples(filtered_df)